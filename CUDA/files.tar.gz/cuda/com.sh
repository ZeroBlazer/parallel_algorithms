/usr/local/cuda/bin/nvcc matrixSum.cu -o run1
/usr/local/cuda/bin/nvcc grayScale.cu -o run2
